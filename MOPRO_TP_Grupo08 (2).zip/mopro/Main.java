
package mopro;

import mopro.dados.GestorDados;
import mopro.interfaces.Menu;

public class Main {
    public static void main(String[] args) {
        GestorDados gestor = new GestorDados();
        gestor.carregarDadosTeste(); // carregar dados iniciais para teste
        Menu menu = new Menu(gestor);
        menu.executar();
    }
}
