
package mopro.dados;

import java.util.ArrayList;
import java.util.List;

public class GestorDados {
    private List<String> barracas;
    private List<String> voluntarios;

    public GestorDados() {
        barracas = new ArrayList<>();
        voluntarios = new ArrayList<>();
    }

    public void carregarDadosTeste() {
        barracas.add("Barraca Engenharias");
        barracas.add("Barraca Medicina");
        voluntarios.add("João Silva - Eng. Informática");
        voluntarios.add("Maria Costa - Medicina");
    }

    public void listarBarracas() {
        System.out.println("--- Barracas ---");
        for (String b : barracas) {
            System.out.println(b);
        }
    }

    public void listarVoluntarios() {
        System.out.println("--- Voluntários ---");
        for (String v : voluntarios) {
            System.out.println(v);
        }
    }
}
