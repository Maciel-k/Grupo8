
package mopro.interfaces;

import mopro.dados.GestorDados;

import java.util.Scanner;

public class Menu {
    private GestorDados gestor;
    private Scanner scanner;

    public Menu(GestorDados gestor) {
        this.gestor = gestor;
        this.scanner = new Scanner(System.in);
    }

    public void executar() {
        int opcao;
        do {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Listar barracas");
            System.out.println("2. Listar voluntários");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> gestor.listarBarracas();
                case 2 -> gestor.listarVoluntarios();
                case 0 -> System.out.println("A sair...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }
}
