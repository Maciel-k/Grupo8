
# Sistema de Gestão de Barracas - Grupo 8

Este projeto implementa um sistema de gestão das barracas da Queima das Fitas,
em conformidade com os requisitos da unidade curricular MOPRO (Modelação e Programação).

## Estrutura do Projeto

- `src/model/`: Classes de domínio (Barraca, Produto, Voluntário, etc.)
- `src/controller/`: Lógica de negócio e gestão
- `src/view/`: Interfaces com o utilizador (menu de consola)
- `test/`: Testes unitários (JUnit)
- `uml/`: Diagrama UML de classes (`.puml`)

## Funcionalidades
- Gestão de barracas, voluntários, produtos e escalas
- Registo de vendas e reposição de stock
- Classificação de barracas e voluntários (bronze, prata, ouro)
- Listagens ordenadas por critérios
- Serialização e persistência de dados
- Interface de consola para interação
- Testes unitários
- JavaDoc em todas as classes públicas

## Como executar
Compilar e correr a classe `Main` em `src/Main.java`.

---
Grupo 8 - MOPRO 2024/25
