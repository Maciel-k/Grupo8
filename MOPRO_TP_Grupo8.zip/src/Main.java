/**
 * Main application class.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Sistema de Gestão de Barracas - Grupo 8");
        // TODO: Implementar menu principal e lógica
    }
}
