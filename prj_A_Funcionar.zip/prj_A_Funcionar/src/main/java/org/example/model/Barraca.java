package org.example.model;

import org.example.model.pessoa.VoluntarioVendas;

import org.example.model.pessoa.Voluntario;
import org.example.model.exceptions.AssociacaoInvalidaException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Classe que representa uma barraca no sistema.
 */
public class Barraca implements Serializable, model.sistema.Classificavel {
    private String nome;
    private String instituicao;
    private List<Produto> produtos;
    private List<Voluntario> voluntarios;
    private Map<String, List<Voluntario>> escalasDiarias; // Key: dia, Value: lista de voluntários
    private double vendasTotais;
    private int stockFinalDiario;
    private List<model.Venda> historicoVendas;

    public Barraca(String nome, String instituicao) {
        this.nome = nome;
        this.instituicao = instituicao;
        this.produtos = new ArrayList<>();
        this.voluntarios = new ArrayList<>();
        this.escalasDiarias = new HashMap<>();
        this.vendasTotais = 0.0;
        this.stockFinalDiario = 0;
        this.historicoVendas = new ArrayList<>();
    }

    // Métodos para produtos
    public void adicionarProduto(Produto produto) {
        produtos.add(produto);
    }

    public Produto encontrarProduto(String nomeProduto) {
        return produtos.stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nomeProduto))
                .findFirst()
                .orElse(null);
    }

    // Métodos para voluntários
    public void adicionarVoluntario(Voluntario voluntario) throws AssociacaoInvalidaException {
        if (!voluntario.getInstituicao().equals(this.instituicao)) {
            throw new AssociacaoInvalidaException("O voluntário não pertence à mesma instituição da barraca.");
        }

        if (voluntario.getBarracaAssociada() != null) {
            throw new AssociacaoInvalidaException("O voluntário já está associado a outra barraca.");
        }

        voluntarios.add(voluntario);
        voluntario.setBarracaAssociada(this);
    }

    // Métodos para escalas
    public void adicionarVoluntarioEscala(String dia, Voluntario voluntario) throws AssociacaoInvalidaException {
        escalasDiarias.putIfAbsent(dia, new ArrayList<>());
        List<Voluntario> escalaDia = escalasDiarias.get(dia);

        // Verifica limite de voluntários de vendas
        if (voluntario instanceof VoluntarioVendas) {
            long numVendedores = escalaDia.stream()
                    .filter(v -> v instanceof VoluntarioVendas)
                    .count();
            if (numVendedores >= 2) {
                throw new AssociacaoInvalidaException("Limite de 2 voluntários de vendas atingido para este dia.");
            }
        }

        escalaDia.add(voluntario);
    }


    // Métodos para vendas
    public void registrarVenda(model.Venda venda) {
        this.vendasTotais += venda.getValorTotal();
        this.historicoVendas.add(venda);
        this.stockFinalDiario = calcularStockFinalDiario();
    }

    private int calcularStockFinalDiario() {
        return produtos.stream()
                .mapToInt(Produto::getStock)
                .sum();
    }

    // Getters
    public String getNome() { return nome; }
    public String getInstituicao() { return instituicao; }
    public List<Produto> getProdutos() { return new ArrayList<>(produtos); }
    public List<Voluntario> getVoluntarios() { return new ArrayList<>(voluntarios); }
    public Map<String, List<Voluntario>> getEscalasDiarias() { return new HashMap<>(escalasDiarias); }
    public double getVendasTotais() { return vendasTotais; }
    public int getStockFinalDiario() { return stockFinalDiario; }
    public List<model.Venda> getHistoricoVendas() { return new ArrayList<>(historicoVendas); }

    @Override
    public String getClassificacao() {
        if (stockFinalDiario > 100) {
            return "Bronze";
        } else if (stockFinalDiario >= 50) {
            return "Prata";
        } else {
            return "Ouro";
        }
    }

}