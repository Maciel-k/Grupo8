package org.example.model.main;

import org.example.model.exceptions.StockInsuficienteException;

import org.example.model.pessoa.*;
import org.example.model.*;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final model.sistema.GerenciadorSistema sistema = new model.sistema.GerenciadorSistema();

    public static void main(String[] args) {
        exibirMenuInicial();
    }

    private static void exibirMenuInicial() {
        while (true) {
            System.out.println("\n=== SISTEMA DE BARRACAS ===");
            System.out.println("1. Login");
            System.out.println("2. Sair");
            System.out.print("Escolha: ");

            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer

            switch (opcao) {
                case 1:
                    fazerLogin();
                    break;
                case 2:
                    System.exit(0);
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    private static void fazerLogin() {
        System.out.print("\nNúmero de identificação: ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (sistema.autenticar(numero, password)) {
            redirecionarParaMenuTipoUsuario();
        } else {
            System.out.println("Autenticação falhou!");
        }
    }

    private static void redirecionarParaMenuTipoUsuario() {
        if (sistema.getUsuarioLogado() instanceof Administrador) {
            menuAdministrador();
        } else if (sistema.getUsuarioLogado() instanceof VoluntarioVendas) {
            menuVoluntarioVendas();
        } else if (sistema.getUsuarioLogado() instanceof VoluntarioStock) {
            menuVoluntarioStock();
        }
    }

    // MENU ADMINISTRADOR
    private static void menuAdministrador() {
        while (true) {
            System.out.println("\n=== MENU ADMINISTRADOR ===");
            System.out.println("1. Gerenciar barracas");
            System.out.println("2. Gerenciar voluntários");
            System.out.println("3. Relatórios");
            System.out.println("4. Logout");
            System.out.print("Escolha: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    menuGerenciarBarracas();
                    break;
                case 2:
                    menuGerenciarVoluntarios();
                    break;
                case 3:
                    menuRelatorios();
                    break;
                case 4:
                    sistema.logout();
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    // MENU VOLUNTÁRIO VENDAS
    private static void menuVoluntarioVendas() {
        VoluntarioVendas voluntario = (VoluntarioVendas) sistema.getUsuarioLogado();

        while (true) {
            System.out.println("\n=== MENU VENDAS ===");
            System.out.printf("Bem-vindo, %s (Vendas: %.2f€ - %s)\n",
                    voluntario.getNome(),
                    voluntario.getTotalVendas(),
                    voluntario.getClassificacao());
            System.out.println("1. Realizar venda");
            System.out.println("2. Listar produtos");
            System.out.println("3. Logout");
            System.out.print("Escolha: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    realizarVenda();
                    break;
                case 2:
                    sistema.listarProdutos();
                    break;
                case 3:
                    sistema.logout();
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    // MENU VOLUNTÁRIO STOCK
    private static void menuVoluntarioStock() {
        while (true) {
            System.out.println("\n=== MENU STOCK ===");
            System.out.println("1. Adicionar produto");
            System.out.println("2. Repor stock");
            System.out.println("3. Listar produtos");
            System.out.println("4. Logout");
            System.out.print("Escolha: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    adicionarProduto();
                    break;
                case 2:
                    reporStock();
                    break;
                case 3:
                    sistema.listarProdutos();
                    break;
                case 4:
                    sistema.logout();
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    // OPERAÇÕES DE VENDA
    private static void realizarVenda() {
        System.out.println("\n=== NOVA VENDA ===");
        sistema.listarBarracas();

        System.out.print("\nBarraca: ");
        String barraca = scanner.nextLine();

        System.out.print("Produto: ");
        String produto = scanner.nextLine();

        System.out.print("Quantidade: ");
        int quantidade = scanner.nextInt();
        scanner.nextLine();

        try {
            sistema.realizarVenda(
                    barraca,
                    produto,
                    quantidade,
                    (VoluntarioVendas) sistema.getUsuarioLogado()
            );
            System.out.println("Venda registrada com sucesso!");
        } catch (StockInsuficienteException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    // OPERAÇÕES DE STOCK
    private static void adicionarProduto() {
        System.out.println("\n=== NOVO PRODUTO ===");
        sistema.listarBarracas();

        System.out.print("\nBarraca: ");
        String nomeBarraca = scanner.nextLine();

        System.out.print("Nome do produto: ");
        String nomeProduto = scanner.nextLine();

        System.out.print("Preço: ");
        double preco = scanner.nextDouble();

        System.out.print("Stock inicial: ");
        int stock = scanner.nextInt();
        scanner.nextLine();

        sistema.adicionarProdutoABarraca(
                nomeBarraca,
                new Produto(nomeProduto, preco, stock)
        );
        System.out.println("Produto adicionado com sucesso!");
    }

    // MÉTODOS AUXILIARES (outras operações similares)
    private static void reporStock() {
        // Implementação similar à adicionarProduto()
    }

    private static void menuRelatorios() {
        sistema.gerarRelatorioClassificacao();
    }

    private static void menuGerenciarBarracas() {
        // Implementação para gerenciar barracas
    }

    private static void menuGerenciarVoluntarios() {
        // Implementação para gerenciar voluntários
    }
}