

package model.sistema;

/**
 * Interface que define o comportamento de classificação.
 */
public interface Classificavel {
    String getClassificacao();
}