package model.sistema;



import org.example.model.Barraca;
import org.example.model.Produto;
import org.example.model.exceptions.AssociacaoInvalidaException;
import org.example.model.exceptions.StockInsuficienteException;
import org.example.model.pessoa.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Classe principal que gerencia todo o sistema.
 */

import org.example.model.*;
import org.example.model.pessoa.*;

import java.util.*;
import java.util.stream.Collectors;

public class GerenciadorSistema {
    private List<Pessoa> pessoas;
    private List<Barraca> barracas;
    private List<model.Venda> vendas;
    private Pessoa usuarioLogado;

    public GerenciadorSistema() {
        this.pessoas = new ArrayList<>();
        this.barracas = new ArrayList<>();
        this.vendas = new ArrayList<>();
        inicializarDadosTeste();
    }

    private void inicializarDadosTeste() {
        // Administrador
        Administrador admin = new Administrador("Admin", 1, "LES", "admin123", "FAP");
        pessoas.add(admin);

        // Voluntários
        VoluntarioVendas volVendas1 = new VoluntarioVendas("João Vendas", 1001, "LES", "joao123", "FEUP");
        VoluntarioVendas volVendas2 = new VoluntarioVendas("Maria Vendas", 1002, "LEI", "maria123", "FEUP");
        VoluntarioStock volStock1 = new VoluntarioStock("Carlos Stock", 1003, "LES", "carlos123", "FEUP");
        pessoas.addAll(List.of(volVendas1, volVendas2, volStock1));

        // Barraca com produtos
        Barraca barracaFEUP = new Barraca("Barraca FEUP", "FEUP");
        barracaFEUP.adicionarProduto(new Produto("Cerveja", 2.5, 100));
        barracaFEUP.adicionarProduto(new Produto("Hambúrguer", 5.0, 50));
        barracas.add(barracaFEUP);

        Barraca barracaISEP = new Barraca("Barraca ISEP", "ISEP");
        barracaISEP.adicionarProduto(new Produto("Cerveja", 2.5, 100));
        barracaISEP.adicionarProduto(new Produto("pão", 5.5,60));
        barracas.add(barracaISEP);
    }

    // Autenticação
    public boolean autenticar(int numeroId, String password) {
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getNumeroIdentificacao() == numeroId &&
                    pessoa.getPassword().equals(password)) {
                usuarioLogado = pessoa;
                return true;
            }
        }
        return false;
    }

    public void logout() {
        usuarioLogado = null;
    }

    // Gerenciamento de Barracas
    public void adicionarBarraca(Barraca barraca) {
        barracas.add(barraca);
    }

    // Gerenciamento de Pessoas
    public void adicionarPessoa(Pessoa pessoa) {
        pessoas.add(pessoa);
    }

    // Operações de Venda
    public void realizarVenda(String nomeBarraca, String nomeProduto, int quantidade, VoluntarioVendas voluntario)
            throws StockInsuficienteException {

        Barraca barraca = barracas.stream()
                .filter(b -> b.getNome().equalsIgnoreCase(nomeBarraca))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Barraca não encontrada"));

        Produto produto = barraca.getProdutos().stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nomeProduto))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Produto não encontrado"));

        produto.reduzirStock(quantidade);
        double valorVenda = produto.getPreco() * quantidade;

        // Registra a venda
        model.Venda venda = new model.Venda(produto, quantidade, voluntario);
        vendas.add(venda);
        barraca.registrarVenda(venda);
        voluntario.adicionarVenda(valorVenda);
    }

    // Relatórios
    public void gerarRelatorioClassificacao() {
        System.out.println("\n=== CLASSIFICAÇÃO DE VOLUNTÁRIOS ===");
        pessoas.stream()
                .filter(p -> p instanceof VoluntarioVendas)
                .map(p -> (VoluntarioVendas) p)
                .sorted(Comparator.comparingDouble(VoluntarioVendas::getTotalVendas).reversed())
                .forEach(v -> System.out.printf("- %s: %.2f€ (%s)\n",
                        v.getNome(), v.getTotalVendas(), v.getClassificacao()));

        System.out.println("\n=== CLASSIFICAÇÃO DE BARRACAS ===");
        barracas.stream()
                .sorted(Comparator.comparingDouble(Barraca::getVendasTotais).reversed())
                .forEach(b -> System.out.printf("- %s: %.2f€ (%s)\n",
                        b.getNome(), b.getVendasTotais(), b.getClassificacao()));
    }

    public void listarVoluntariosPorNumero() {
        System.out.println("\n=== VOLUNTÁRIOS ORDENADOS POR NÚMERO ===");

        getVoluntarios().stream()
                .sorted(Comparator.comparingInt(Voluntario::getNumeroIdentificacao))
                .forEach(v -> System.out.printf(
                        "Nº %d - %s (%s - %s)\n",
                        v.getNumeroIdentificacao(),
                        v.getNome(),
                        v.getTipo(),
                        v.getInstituicao()
                ));
    }






    // Getters
    public Pessoa getUsuarioLogado() { return usuarioLogado; }
    public List<Barraca> getBarracas() { return barracas; }
    public List<Pessoa> getPessoas() { return pessoas; }

    // Método auxiliar para encontrar voluntários
    public List<Voluntario> getVoluntarios() {
        return pessoas.stream()
                .filter(p -> p instanceof Voluntario)
                .map(p -> (Voluntario) p)
                .collect(Collectors.toList());
    }
    public void listarProdutos() {
        System.out.println("\n=== LISTA DE PRODUTOS ===");

        for (Barraca barraca : barracas) {
            System.out.println("\nBarraca: " + barraca.getNome());

            if (barraca.getProdutos().isEmpty()) {
                System.out.println("  Nenhum produto cadastrado");
            } else {
                for (Produto produto : barraca.getProdutos()) {
                    System.out.printf("  %s - Preço: %.2f€ | Stock: %d\n",
                            produto.getNome(),
                            produto.getPreco(),
                            produto.getStock());
                }
            }
        }
    }
    public void adicionarProdutoABarraca(String nomeBarraca, Produto produto) {
        // Encontra a barraca pelo nome
        Barraca barraca = barracas.stream()
                .filter(b -> b.getNome().equalsIgnoreCase(nomeBarraca))
                .findFirst()
                .orElse(null);

        if (barraca != null) {
            // Verifica se o produto já existe
            if (barraca.getProdutos().stream()
                    .anyMatch(p -> p.getNome().equalsIgnoreCase(produto.getNome()))) {
                System.out.println("Erro: Já existe um produto com este nome na barraca.");
            } else {
                barraca.adicionarProduto(produto);
                System.out.println("Produto adicionado com sucesso!");
            }
        } else {
            System.out.println("Erro: Barraca não encontrada!");
        }
    }

    public void listarBarracas() {
        if (barracas.isEmpty()) {
            System.out.println("\nNão há barracas cadastradas.");
            return;
        }

        System.out.println("\n=== LISTA DE BARRACAS ===");
        for (int i = 0; i < barracas.size(); i++) {
            Barraca b = barracas.get(i);
            System.out.printf("%d. %s (%s)\n", i+1, b.getNome(), b.getInstituicao());
            System.out.printf("   Produtos: %d | Voluntários: %d\n",
                    b.getProdutos().size(), b.getVoluntarios().size());
        }
    }

}