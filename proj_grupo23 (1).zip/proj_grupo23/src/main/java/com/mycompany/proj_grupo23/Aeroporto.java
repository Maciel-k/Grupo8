/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa um aeroporto com código, endereço e página web.
 * 
 * @author pedro
 */
public class Aeroporto {
    private int codigo;
    private String endereco;
    private String paginaWeb;
    private final String STRING_OMISSAO = "Por Definir...";
    private final int INT_OMISSAO = 0;

    /**
     * Construtor com parâmetros.
     * 
     * @param codigo    O código do aeroporto.
     * @param endereco  O endereço do aeroporto.
     * @param paginaWeb A página web do aeroporto.
     */
    public Aeroporto(int codigo, String endereco, String paginaWeb) {
        this.codigo = codigo;
        this.endereco = endereco;
        this.paginaWeb = paginaWeb;
    }

    /**
     * Construtor sem parâmetros.
     */
    public Aeroporto() {
        this.codigo = INT_OMISSAO;
        this.endereco = STRING_OMISSAO;
        this.paginaWeb = STRING_OMISSAO;
    }

    /**
     * Construtor de cópia.
     * 
     * @param a1 O aeroporto a ser copiado.
     */
    public Aeroporto(Aeroporto a1){
        this.codigo = a1.codigo;
        this.endereco = a1.endereco;
        this.paginaWeb = a1.paginaWeb;
    }

  /**
     * Obtém o código do aeroporto.
     * 
     * @return O código do aeroporto.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Define o código do aeroporto.
     * 
     * @param codigo O código do aeroporto.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtém o endereço do aeroporto.
     * 
     * @return O endereço do aeroporto.
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * Define o endereço do aeroporto.
     * 
     * @param endereco O endereço do aeroporto.
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * Obtém a página web do aeroporto.
     * 
     * @return A página web do aeroporto.
     */
    public String getPaginaWeb() {
        return paginaWeb;
    }

    /**
     * Define a página web do aeroporto.
     * 
     * @param paginaWeb A página web do aeroporto.
     */
    public void setPaginaWeb(String paginaWeb) {
        this.paginaWeb = paginaWeb;
    }

    /**
     * Retorna uma representação em string do aeroporto.
     * 
     * @return Uma string que representa o aeroporto.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Aeroporto{");
        sb.append("codigo=").append(codigo);
        sb.append(", endereco=").append(endereco);
        sb.append(", paginaWeb=").append(paginaWeb);
        sb.append('}');
        return sb.toString();
    }
}