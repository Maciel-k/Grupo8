/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

import java.util.Objects;

/** 
 * Classe que representa um Cliente e os seus dados 
 * 
 * @author pedro
 */
public class Cliente {
    private static int proximoCodigo = 1;
    private int codigo;
    private String nome;
    private Data dataNascimento;
    private String nif;
    private int numPassaporte;
    private String email;

    private final String STRING_OMISSAO = "Por Definit...";
    private final int INT_OMISSAO = 0;
    private final Data DATA_OMISSAO = new Data();
    
    /**
     * Construtor com parâmetros.
     * 
     * @param nome          O nome do cliente.
     * @param dataNascimento A data de nascimento do cliente.
     * @param nif           O NIF do cliente.
     * @param numPassaporte O número do passaporte do cliente.
     * @param email         O email do cliente.
     */
    public Cliente(String nome, Data dataNascimento, int nif, int numPassaporte, String email) {
        if (("" + nif).length() != 9) {
            throw new IllegalArgumentException("O NIF deve conter exatamente 9 caracteres numéricos.");
        }
        if (!nome.matches("[a-zA-Z\\s]+")) {
            throw new IllegalArgumentException("O nome do cliente deve conter apenas letras e espaços.");
        }
        
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.nif = "" + nif;
        this.numPassaporte = numPassaporte;
        this.email = email;
    }
    
    /**
     * Construtor sem parâmetros.
     * <p>Inicializa um cliente com valores padrão:</p>
     * <ul>
     * <li>codigo: próximo código disponível</li>
     * <li>nome: "Por Definir..."</li>
     * <li>dataNascimento: Data padrão (01/01/2000)</li>
     * <li>nif: "Por Definir..."</li>
     * <li>numPassaporte: 0</li>
     * <li>email: "Por Definir..."</li>
     * </ul>
     */
    public Cliente() {
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.nome = STRING_OMISSAO;
        this.dataNascimento = DATA_OMISSAO;
        this.nif = STRING_OMISSAO;
        this.numPassaporte = INT_OMISSAO;
        this.email = STRING_OMISSAO;
    }
    
    /**
     * Construtor de cópia.
     * 
     * @param c1 O cliente a ser copiado.
     */
    public Cliente(Cliente c1) {
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.nome = c1.nome;
        this.dataNascimento = c1.dataNascimento;
        this.nif = c1.nif;
        this.numPassaporte = c1.numPassaporte;
        this.email = c1.email;
    }

    /**
     * Obtém o próximo código disponível.
     * 
     * @return O próximo código disponível.
     */
    public static int getProximoCodigo() {
        return proximoCodigo;
    }

    /**
     * Define o próximo código disponível.
     * 
     * @param proximoCodigo O próximo código a ser definido.
     */
    public static void setProximoCodigo(int proximoCodigo) {
        Cliente.proximoCodigo = proximoCodigo;
    }

    /**
     * Obtém o código do cliente.
     * 
     * @return O código do cliente.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Define o código do cliente.
     * 
     * @param codigo O código do cliente.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtém o nome do cliente.
     * 
     * @return O nome do cliente.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do cliente.
     * 
     * @param nome O nome do cliente.
     */
    public void setNome(String nome) {
        if (!nome.matches("[a-zA-Z\\s]+")) {
            throw new IllegalArgumentException("O nome do cliente deve conter apenas letras e espaços.");
        }
        this.nome = nome;
    }

    /**
     * Obtém a data de nascimento do cliente.
     * 
     * @return A data de nascimento do cliente.
     */
    public Data getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Define a data de nascimento do cliente.
     * 
     * @param dataNascimento A data de nascimento do cliente.
     */
    public void setDataNascimento(Data dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    /**
     * Obtém o NIF do cliente.
     * 
     * @return O NIF do cliente.
     */
    public String getNif() {
        return nif;
    }

    /**
     * Define o NIF do cliente.
     * 
     * @param nif O NIF do cliente.
     */
    public void setNif(String nif) {
        if (nif.length() != 9) {
            throw new IllegalArgumentException("O NIF deve conter exatamente 9 caracteres numéricos.");
        }
        this.nif = nif;
    }

    /**
     * Obtém o número do passaporte do cliente.
     * 
     * @return O número do passaporte do cliente.
     */
    public int getNumPassaporte() {
        return numPassaporte;
    }

    /**
     * Define o número do passaporte do cliente.
     * 
     * @param numPassaporte O número do passaporte do cliente.
     */
    public void setNumPassaporte(int numPassaporte) {
        this.numPassaporte = numPassaporte;
    }

    /**
     * Obtém o email do cliente.
     * 
     * @return O email do cliente.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Define o email do cliente.
     * 
     * @param email O email do cliente.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Retorna uma representação em string do cliente.
     * 
     * @return Uma string que representa o cliente.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Cliente{");
        sb.append("codigo=").append(codigo);
        sb.append(", nome=").append(nome);
        sb.append(", dataNascimento=").append(dataNascimento);
        sb.append(", nif=").append(nif);
        sb.append(", numPassaporte=").append(numPassaporte);
        sb.append(", email=").append(email);
        sb.append('}');
        return sb.toString();
    }
}