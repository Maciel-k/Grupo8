/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa uma data, com dia, mes e ano
 * 
 * @author pedro
 */
public class Data {
    private int dia;
    private int mes;
    private int ano;

    /**
     * Construtor com parâmetros.
     * 
     * @param dia O dia da data.
     * @param mes O mês da data.
     * @param ano O ano da data.
     */
    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }
    
    /**
     * Construtor sem parâmetros, inicializa a data para 1/1/0.
     */
    public Data() {
        this.dia = 1;
        this.mes = 1;
        this.ano = 0;
    }
    
    /**
     * Construtor de cópia.
     * 
     * @param d1 A data a ser copiada.
     */
    public Data(Data d1) {
        this.dia = d1.dia;
        this.mes = d1.mes;
        this.ano = d1.ano;
    }

    /**
     * Obtém o dia da data.
     * 
     * @return O dia da data.
     */
    public int getDia() {
        return dia;
    }

    /**
     * Define o dia da data.
     * 
     * @param dia O dia a ser definido.
     */
    public void setDia(int dia) {
        this.dia = dia;
    }

    /**
     * Obtém o mês da data.
     * 
     * @return O mês da data.
     */
    public int getMes() {
        return mes;
    }

    /**
     * Define o mês da data.
     * 
     * @param mes O mês a ser definido.
     */
    public void setMes(int mes) {
        this.mes = mes;
    }

    /**
     * Obtém o ano da data.
     * 
     * @return O ano da data.
     */
    public int getAno() {
        return ano;
    }

    /**
     * Define o ano da data.
     * 
     * @param ano O ano a ser definido.
     */
    public void setAno(int ano) {
        this.ano = ano;
    }

    /**
     * Compara duas datas.
     * 
     * <p>Compara duas datas e retorna:</p>
     * <ul>
     * <li>1 se a primeira data for posterior à segunda data.</li>
     * <li>-1 se a primeira data for anterior à segunda data.</li>
     * <li>0 se ambas as datas forem iguais.</li>
     * </ul>
     * 
     * @param d1 A primeira data a ser comparada.
     * @param d2 A segunda data a ser comparada.
     * @return O resultado da comparação.
     */
    public static int CompararDatas(Data d1, Data d2){
        if(d1.getAno() > d2.getAno()) {
            return 1;
        } else if (d2.getAno() > d1.getAno()) {
            return -1;
        } else if (d1.getMes() > d2.getMes()) {
            return 1;
        } else if (d2.getMes() > d1.getMes()) {
            return -1;
        } else if (d1.getDia() > d2.getDia()) {
            return 1;
        } else if (d2.getDia() > d1.getDia()) {
            return -1;
        } else {
            return 0;
        }
    }
    
    /**
     * Retorna uma representação em string da data.
     * 
     * @return Uma string que representa a data no formato "dia/mês/ano".
     */
    @Override
    public String toString() {
        return (this.dia + "/" + this.mes + "/" + this.ano);
    }
}