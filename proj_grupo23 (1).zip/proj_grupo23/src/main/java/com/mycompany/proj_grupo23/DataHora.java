/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa uma data e hora, estendendo a classe Data.
 * Permite armazenar informações de hora e minuto além dos dados de data.
 * 
 * @author pedro
 */
public class DataHora extends Data {
    private int hora;
    private int minuto;
    private final int INT_OMISSAO = 0;

    /**
     * Construtor que inicializa a data e hora com valores específicos.
     * 
     * @param dia     O dia.
     * @param mes     O mês.
     * @param ano     O ano.
     * @param hora    A hora.
     * @param minuto  O minuto.
     */
    public DataHora(int dia, int mes, int ano, int hora, int minuto) {
        super(dia, mes, ano);
        this.hora = hora;
        this.minuto = minuto;
    }

    /**
     * Construtor que inicializa a data e hora com valores padrão (omissão).
     */
    public DataHora() {
        super();
        this.hora = INT_OMISSAO;
        this.minuto = INT_OMISSAO;
    }

    /**
     * Construtor que inicializa a data e hora a partir de outro objeto DataHora.
     * 
     * @param other Outro objeto DataHora a ser copiado.
     */
    public DataHora(DataHora other) {
        super(other.getDia(), other.getMes(), other.getAno());
        this.hora = other.hora;
        this.minuto = other.minuto;
    }

    /**
     * Obtém a hora.
     * 
     * @return A hora.
     */
    public int getHora() {
        return hora;
    }

    /**
     * Define a hora.
     * 
     * @param hora A hora a ser definida.
     */
    public void setHora(int hora) {
        this.hora = hora;
    }

    /**
     * Obtém o minuto.
     * 
     * @return O minuto.
     */
    public int getMinuto() {
        return minuto;
    }

    /**
     * Define o minuto.
     * 
     * @param minuto O minuto a ser definido.
     */
    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    /**
     * Retorna uma representação em string da data e hora no formato "dd/mm/aaaa; hh:mm".
     * 
     * @return Uma representação em string da data e hora.
     */
    @Override
    public String toString() {
        String parteHora = hora + ":" + minuto;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("; " + parteHora);
        return sb.toString();
    }
}