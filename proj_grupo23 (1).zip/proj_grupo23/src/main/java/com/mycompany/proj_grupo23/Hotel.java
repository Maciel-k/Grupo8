/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa um Hotel, com dados como um código, uma sigla,
 * categoria, transfer, localidade e preco por quarto.
 * 
 * @author pedro
 */

public class Hotel implements ICategoriaEservico {
    private static int proximoCodigo = 1;
    private int codigo;
    private String sigla;
    private String categoria;
    private boolean transfer;
    private String localidade;
    private float precoQuarto;
    
    private final String STRING_OMISSAO = "Por Definir...";
    private final int INT_OMISSAO = 0;
    private final float FLOAT_OMISSAO = 0.0f;
    private final boolean BOOL_OMISSAO = false;

    /**
     * Construtor com parâmetros.
     * 
     * @param codigo O código do hotel.
     * @param sigla A sigla do hotel.
     * @param localidade A localidade do hotel.
     * @param precoQuarto O preço do quarto do hotel.
     * @param categoria A categoria do hotel.
     * @param transfer Disponibilidade de transfer do hotel.
     */
    public Hotel(int codigo, String sigla, String localidade, float precoQuarto, String categoria, boolean transfer) {
        if (precoQuarto < 0) {
            throw new IllegalArgumentException("O preço do quarto não pode ser negativo.");
        }
        
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.sigla = sigla;
        this.categoria = categoria;
        this.localidade = localidade;
        this.precoQuarto = precoQuarto;
        this.transfer = transfer;
    }
    
    /**
     * Construtor sem parâmetros, inicializa os atributos com valores predefinidos.
     */
    public Hotel() {
        this.codigo = INT_OMISSAO;
        this.sigla = STRING_OMISSAO;
        this.categoria = STRING_OMISSAO;
        this.localidade = STRING_OMISSAO;
        this.precoQuarto = FLOAT_OMISSAO;
        this.transfer = BOOL_OMISSAO;
    }
    
    /**
     * Construtor de cópia.
     * 
     * @param h1 O hotel a ser copiado.
     */
    public Hotel(Hotel h1) {
        this.codigo = h1.codigo;
        this.sigla = h1.sigla;
        this.categoria = h1.categoria;
        this.localidade = h1.localidade;
        this.precoQuarto = h1.precoQuarto;
        this.transfer = h1.transfer;
    }

    /**
     * Obtém o próximo código disponível.
     * 
     * @return O próximo código.
     */
    public static int getProximo_codigo() {
        return proximoCodigo;
    }

    /**
     * Define o próximo código.
     * 
     * @param proximoCodigo O próximo código a ser definido.
     */
    public static void setProximo_codigo(int proximoCodigo) {
        Hotel.proximoCodigo = proximoCodigo;
    }

    /**
     * Obtém o código do hotel.
     * 
     * @return O código do hotel.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Define o código do hotel.
     * 
     * @param codigo O código a ser definido.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtém a sigla do hotel.
     * 
     * @return A sigla do hotel.
     */
    public String getSigla() {
        return sigla;
    }

    /**
     * Define a sigla do hotel.
     * 
     * @param sigla A sigla a ser definida.
     */
    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    /**
     * Obtém a categoria do hotel.
     * 
     * @return A categoria do hotel.
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     * Define a categoria do hotel.
     * 
     * @param categoria A categoria a ser definida.
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    /**
     * Verifica se o hotel oferece transfer.
     * 
     * @return {@code true} se o hotel oferece transfer, {@code false} caso contrário.
     */
    public boolean isTransfer() {
        return transfer;
    }

    /**
     * Define a disponibilidade de transfer do hotel.
     * 
     * @param transfer A disponibilidade de transfer a ser definida.
     */
    public void setTransfer(boolean transfer) {
        this.transfer = transfer;
    }

    /**
     * Obtém a localidade do hotel.
     * 
     * @return A localidade do hotel.
     */
    public String getLocalidade() {
        return localidade;
    }

    /**
     * Define a localidade do hotel.
     * 
     * @param localidade A localidade a ser definida.
     */
    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }

    /**
     * Obtém o preço do quarto do hotel.
     * 
     * @return O preço do quarto do hotel.
     */
    public float getPreco_quarto() {
        return precoQuarto;
    }

    /**
     * Define o preço do quarto do hotel.
     * 
     * @param precoQuarto O preço do quarto a ser definido.
     */
    public void setPreco_quarto(float precoQuarto) {
        if (precoQuarto < 0) {
            throw new IllegalArgumentException("O preço do quarto não pode ser negativo.");
        }
        this.precoQuarto = precoQuarto;
    }
    
    /**
     * Verifica se o hotel oferece transfer.
     * 
     * @return {@code true} se o hotel oferece transfer, {@code false} caso contrário.
     */
    @Override
    public boolean oferecerTransfer() {
        return transfer;
    }

    /**
     * Retorna uma representação em string do hotel.
     * 
     * @return Uma string que representa o hotel.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Hotel{");
        sb.append("codigo=").append(codigo);
        sb.append(", sigla=").append(sigla);
        sb.append(", categoria=").append(categoria);
        sb.append(", transfer=").append(transfer);
        sb.append(", localidade=").append(localidade);
        sb.append(", precoQuarto=").append(precoQuarto);
        sb.append('}');
        return sb.toString();
    }
}