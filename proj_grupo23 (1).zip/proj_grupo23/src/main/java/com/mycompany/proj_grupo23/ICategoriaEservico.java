/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Interface que define categorias de serviço.
 * Define categorias de hotéis e especifica se oferecem serviço de transfer.
 * 
 * @author pedro
 */
public interface ICategoriaEservico {
    /**
     * Categoria de hotel 1 estrela.
     */
    public static final String UMA_ESTRELA = "1*";

    /**
     * Categoria de hotel 2 estrelas.
     */
    public static final String DUAS_ESTRELAS = "2*";

    /**
     * Categoria de hotel 3 estrelas.
     */
    public static final String TRES_ESTRELAS = "3*";

    /**
     * Categoria de hotel 4 estrelas.
     */
    public static final String QUATRO_ESTRELAS = "4*";

    /**
     * Categoria de hotel 5 estrelas.
     */
    public static final String CINCO_ESTRELAS = "5*";

    /**
     * Categoria de hotel por omissão (1 estrela).
     */
    public static final String CATEGORIA_POR_OMISSAO = UMA_ESTRELA;

    /**
     * Valor do serviço de transfer por omissão (false).
     */
    public static final boolean SERVICO_POR_OMISSAO = false;

    /**
     * Valida se o hotel oferece serviço de transfer.
     *
     * @return true se oferece serviço de transfer, false caso contrário.
     */
    public boolean oferecerTransfer();
}