/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Interface que define o método para obter o custo de uma reserva.
 * Implementada por classes que representam reservas e calculam seu custo.
 * 
 * @author pedro
 */
public interface IPagavel {
    /**
     * Método que retorna o custo da reserva.
     * 
     * @return O custo da reserva.
     */
    public float obterCustoReserva();
}
