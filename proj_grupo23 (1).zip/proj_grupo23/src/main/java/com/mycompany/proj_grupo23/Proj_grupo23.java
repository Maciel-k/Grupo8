/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proj_grupo23;

/**
 *
 * @author pedro
 */
public class Proj_grupo23 {

    public static void main(String[] args) {
        TravelPlus tp = new TravelPlus();
        
        Aeroporto lisboa = new Aeroporto(1, "Lisboa", "www.aeroportolisboa.pt");
        Aeroporto porto = new Aeroporto(2, "Porto", "www.aeroportoporto.pt");
        Aeroporto faro = new Aeroporto(3, "Faro", "www.aeroportofaro.pt");
        Aeroporto madeira = new Aeroporto(4, "Madeira", "www.aeroportomadeira.pt");
        
        Voo voo1 = new Voo(1, "TAP", 100, lisboa, porto, 50, new DataHora(10, 1, 2009, 10, 30));
        Voo voo2 = new Voo(2, "Ryanair", 100, porto, lisboa, 50, new DataHora(20, 2, 2010, 11, 20));
        Voo voo3 = new Voo(3, "EasyJet", 150, faro, lisboa, 80, new DataHora(15, 5, 2011, 14, 45));
        Voo voo4 = new Voo(4, "TAP", 100, madeira, lisboa, 100, new DataHora(25, 6, 2012, 9, 15));
        Voo voo5 = new Voo(5, "Ryanair", 120, porto, faro, 60, new DataHora(10, 7, 2013, 16, 30));
        Voo voo6 = new Voo(6, "British Airways", 180, madeira, porto, 90, new DataHora(5, 8, 2014, 13, 0));
        
        Cliente cliente1 = new Cliente("Rodrigo Silva", new Data(1,2,1987), 123456789, 123456, "joao@gmail.com");
        Cliente cliente2 = new Cliente("Maria Santos", new Data(22,3,1973), 987654321, 654321, "maria@gmail.com");
        Cliente cliente3 = new Cliente("Ana Oliveira", new Data(3,12,1990), 192837465, 192837, "ana@gmail.com");
        
        Hotel hotel1 = new Hotel(1, "LM", "Lisboa", 150, "5*", true);
        Hotel hotel2 = new Hotel(2, "BT", "Porto", 100, "4*", false);
        Hotel hotel3 = new Hotel(3, "JL", "Faro", 80, "3*", true);
        Hotel hotel4 = new Hotel(4, "RU", "Madeira", 60, "2*", false);

        // Adicionar aeroportos
        tp.adicionarAeroporto(lisboa);
        tp.adicionarAeroporto(porto);
        tp.adicionarAeroporto(faro);
        tp.adicionarAeroporto(madeira);

        // Adicionar voos
        tp.adicionarVoo(voo1);
        tp.adicionarVoo(voo2);

        // Adicionar clientes
        tp.adicionarCliente(cliente1);
        tp.adicionarCliente(cliente2);
        tp.adicionarCliente(cliente3);

        // Adicionar hotéis
        tp.adicionarHotel(hotel1);
        tp.adicionarHotel(hotel2);
        tp.adicionarHotel(hotel3);
        tp.adicionarHotel(hotel4);

        // Adicionar reservas
        tp.fazerReservaHotel(new Data(10, 1, 2005), 2, cliente1, hotel1, new Data(), 3);
        tp.fazerReservaVoo(new Data(10, 1, 2006), 1, cliente2, voo1);
        tp.fazerReservaVooIdaVolta(new Data(9, 1, 2005), 1, cliente1, voo1, voo2);
        tp.fazerReservaHotelVoo(new Data(11, 2, 2003), 1, cliente3, hotel4, new Data(14, 2, 2003), 4, voo6);

        // Listar reservas ordenadas por data
        tp.ordenarReservas();
        System.out.println(tp.listarReservasEmpresa());

        // Listar clientes ordenados por nome
        System.out.println(tp.ordenarClientes());

        // Listar hotéis com transfer
        
        System.out.println("");
        for (Hotel h : tp.listarHoteisComTransfer()) {
            System.out.println(h);
        }
    }
}

