/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe abstrata que representa uma reserva genérica.
 * Implementa a interface IPagavel para calcular o custo da reserva.
 * Define atributos comuns a todas as reservas como código, data, número de pessoas e cliente.
 * 
 * @author pedro
 */
public abstract class Reserva implements IPagavel {
    private static int proximoCodigo = 1;
    private int codigo;
    private Data dataReserva;
    private int numeroPessoas;
    private Cliente cliente;
    
    private final int INT_OMISSAO = 0;
    private final String STRING_OMISSAO = "Por Definir...";
    private final Cliente CLIENTE_OMISSAO = new Cliente();

    /**
     * Construtor que inicializa uma reserva com dados específicos.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     */
    public Reserva(Data dataReserva, int numeroPessoas, Cliente cliente) {
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.dataReserva = dataReserva;
        this.numeroPessoas = numeroPessoas;
        this.cliente = cliente;
    }
    
    /**
     * Construtor que inicializa uma reserva com valores padrão (omissão).
     */
    public Reserva() {
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.dataReserva = new Data(); // Aqui seria necessário inicializar com uma data válida ou tratar adequadamente
        this.numeroPessoas = INT_OMISSAO;
        this.cliente = CLIENTE_OMISSAO;
    }
    
    /**
     * Construtor que inicializa uma reserva a partir de outra reserva (cópia).
     * 
     * @param other A outra reserva a ser copiada.
     */
    public Reserva(Reserva other) {
        this.codigo = proximoCodigo;
        proximoCodigo++;
        this.dataReserva = other.dataReserva;
        this.numeroPessoas = other.numeroPessoas;
        this.cliente = other.cliente;
    }

    /**
     * Obtém o código da reserva.
     * 
     * @return O código da reserva.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Define o código da reserva.
     * 
     * @param codigo O código da reserva a ser definido.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtém a data da reserva.
     * 
     * @return A data da reserva.
     */
    public Data getDataReserva() {
        return dataReserva;
    }

    /**
     * Define a data da reserva.
     * 
     * @param dataReserva A data da reserva a ser definida.
     */
    public void setDataReserva(Data dataReserva) {
        this.dataReserva = dataReserva;
    }

    /**
     * Obtém o número de pessoas da reserva.
     * 
     * @return O número de pessoas da reserva.
     */
    public int getNumeroPessoas() {
        return numeroPessoas;
    }

    /**
     * Define o número de pessoas da reserva.
     * 
     * @param numeroPessoas O número de pessoas da reserva a ser definido.
     */
    public void setNumeroPessoas(int numeroPessoas) {
        this.numeroPessoas = numeroPessoas;
    }

    /**
     * Obtém o cliente associado à reserva.
     * 
     * @return O cliente associado à reserva.
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Define o cliente associado à reserva.
     * 
     * @param cliente O cliente a ser associado à reserva.
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * Retorna uma representação em string da reserva.
     * 
     * @return Uma representação em string da reserva.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Reserva{");
        sb.append("codigo=").append(codigo);
        sb.append(", dataReserva=").append(dataReserva);
        sb.append(", numeroPessoas=").append(numeroPessoas);
        sb.append(", cliente=").append(cliente);
        sb.append(", tipoReserva=").append(getClass().getSimpleName());
        sb.append('}');
        return sb.toString();
    }
    
    
}