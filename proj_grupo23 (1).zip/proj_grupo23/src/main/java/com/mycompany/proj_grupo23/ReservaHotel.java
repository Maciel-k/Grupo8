/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa uma reserva de um hotel
 * extende a classe Reserva e os seus atributos
 * 
 * @author pedro
 */
public class ReservaHotel extends Reserva {
    private Hotel hotel;
    private Data dataChegada;
    private int numeroNoites;

    /**
     * Construtor com parâmetros.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas na reserva.
     * @param cliente       O cliente que fez a reserva.
     * @param hotel         O hotel onde a reserva foi feita.
     * @param dataChegada   A data de chegada ao hotel.
     * @param numeroNoites  O número de noites da reserva.
     */
    public ReservaHotel(Data dataReserva, int numeroPessoas, Cliente cliente, Hotel hotel, Data dataChegada, int numeroNoites) {
        super(dataReserva, numeroPessoas, cliente);
        this.hotel = hotel;
        this.dataChegada = dataChegada;
        this.numeroNoites = numeroNoites;
    }

    /**
     * Obtém o hotel da reserva.
     * 
     * @return O hotel da reserva.
     */
    public Hotel getHotel() {
        return hotel;
    }

    /**
     * Define o hotel da reserva.
     * 
     * @param hotel O hotel a ser definido.
     */
    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    /**
     * Obtém a data de chegada ao hotel.
     * 
     * @return A data de chegada ao hotel.
     */
    public Data getDataChegada() {
        return dataChegada;
    }

    /**
     * Define a data de chegada ao hotel.
     * 
     * @param dataChegada A data de chegada a ser definida.
     */
    public void setDataChegada(Data dataChegada) {
        this.dataChegada = dataChegada;
    }

    /**
     * Obtém o número de noites da reserva.
     * 
     * @return O número de noites da reserva.
     */
    public int getNumeroNoites() {
        return numeroNoites;
    }

    /**
     * Define o número de noites da reserva.
     * 
     * @param numeroNoites O número de noites a ser definido.
     */
    public void setNumeroNoites(int numeroNoites) {
        this.numeroNoites = numeroNoites;
    }

    /**
     * Calcula o custo total da reserva.
     * 
     * <p>O custo da reserva é calculado com base no número de quartos necessários (considerando 2 pessoas por quarto),
     * o preço por quarto e o número de noites. Um custo fixo adicional de 20 é adicionado ao total.</p>
     * 
     * @return O custo total da reserva.
     */
    @Override
    public float obterCustoReserva() {
        int numeroQuartos = (int) Math.ceil(getNumeroPessoas() / 2.0);
        return numeroQuartos * hotel.getPreco_quarto() * numeroNoites + 20;
    }

    /**
     * Retorna uma representação em string da reserva de hotel.
     * 
     * @return Uma string que representa a reserva de hotel.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("ReservaHotel{");
        sb.append("hotel=").append(hotel);
        sb.append(", dataChegada=").append(dataChegada);
        sb.append(", numeroNoites=").append(numeroNoites);
        sb.append('}');
        return sb.toString();
    }
}