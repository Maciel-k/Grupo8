/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe de reserva que combina hotel e um voo
 * Estende a classe ReservaHotel e adiciona os voo
 * 
 * @author pedro
 */
public class ReservaHotelVoo extends ReservaHotel {
    private Voo voo;

    /**
     * Construtor com parâmetros.
     * 
     * @param dataReserva A data da reserva.
     * @param numeroPessoas O número de pessoas na reserva.
     * @param cliente O cliente que fez a reserva.
     * @param hotel O hotel da reserva.
     * @param dataChegada A data de chegada ao hotel.
     * @param numeroNoites O número de noites na reserva.
     * @param voo O voo incluído na reserva.
     */
    public ReservaHotelVoo(Data dataReserva, int numeroPessoas, Cliente cliente, Hotel hotel, Data dataChegada, int numeroNoites, Voo voo) {
        super(dataReserva, numeroPessoas, cliente, hotel, dataChegada, numeroNoites);
        this.voo = voo;
    }

    /**
     * Obtém o custo total da reserva, incluindo o custo do hotel e do voo.
     * 
     * @return O custo total da reserva.
     */
    @Override
    public float obterCustoReserva() {
        return super.obterCustoReserva() + voo.getCusto_bilhete() * getNumeroPessoas();
    }

    /**
     * Retorna uma representação em string da reserva, incluindo detalhes do hotel e do voo.
     * 
     * @return Uma string que representa a reserva.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("ReservaHotelVoo{");
        sb.append("voo=").append(voo);
        sb.append('}');
        return sb.toString();
    }
}
