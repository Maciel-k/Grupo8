/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe de reserva que combina hotel e voos de ida e volta.
 * Estende a classe ReservaHotel e adiciona os voos de ida e volta.
 * 
 * @author pedro
 */
public class ReservaHotelVooIdaVolta extends ReservaHotel {
    private Voo vooIda;
    private Voo vooVolta;

    /**
     * Construtor que inicializa uma reserva de hotel com voos de ida e volta.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param hotel         O hotel reservado.
     * @param dataChegada   A data de chegada ao hotel.
     * @param numeroNoites  O número de noites de estadia.
     * @param vooIda        O voo de ida.
     * @param vooVolta      O voo de volta.
     */
    public ReservaHotelVooIdaVolta(Data dataReserva, int numeroPessoas, Cliente cliente, Hotel hotel, Data dataChegada, int numeroNoites, Voo vooIda, Voo vooVolta) {
        super(dataReserva, numeroPessoas, cliente, hotel, dataChegada, numeroNoites);
        this.vooIda = vooIda;
        this.vooVolta = vooVolta;
    }

    /**
     * Calcula o custo total da reserva, incluindo os custos dos voos de ida e volta.
     * 
     * @return O custo total da reserva.
     */
    @Override
    public float obterCustoReserva() {
        return super.obterCustoReserva() + vooIda.getCusto_bilhete() * getNumeroPessoas() + vooVolta.getCusto_bilhete() * getNumeroPessoas();
    }

    /**
     * Retorna uma representação em string da reserva de hotel com voos de ida e volta.
     * 
     * @return Uma representação em string da reserva.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("ReservaHotelVooIdaVolta{");
        sb.append("vooIda=").append(vooIda);
        sb.append(", vooVolta=").append(vooVolta);
        sb.append('}');
        return sb.toString();
    }
}