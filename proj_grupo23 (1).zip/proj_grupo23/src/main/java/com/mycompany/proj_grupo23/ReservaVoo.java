/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa uma reserva de voo, especializando a classe Reserva.
 * Calcula o custo da reserva de acordo com o voo escolhido.
 * Contém métodos para acessar e definir o voo associado à reserva.
 * 
 * @author pedro
 */
public class ReservaVoo extends Reserva {
    private Voo voo;
    
    private final Voo VOO_OMISSAO = new Voo();

    /**
     * Construtor que inicializa uma reserva de voo com dados específicos.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param voo           O voo reservado.
     */
    public ReservaVoo(Data dataReserva, int numeroPessoas, Cliente cliente, Voo voo) {
        super(dataReserva, numeroPessoas, cliente);
        this.voo = voo;
    }
    
    /**
     * Construtor que inicializa uma reserva de voo com valores padrão (omissão).
     */
    public ReservaVoo() {
        super();
        this.voo = VOO_OMISSAO;
    }
    
    /**
     * Construtor que inicializa uma reserva de voo a partir de outra reserva de voo (cópia).
     * 
     * @param other A outra reserva de voo a ser copiada.
     */
    public ReservaVoo(ReservaVoo other) {
        super(other.getDataReserva(), other.getNumeroPessoas(), other.getCliente());
        this.voo = other.voo;
    }

    /**
     * Obtém o voo associado à reserva.
     * 
     * @return O voo associado à reserva.
     */
    public Voo getVoo() {
        return voo;
    }

    /**
     * Define o voo associado à reserva.
     * 
     * @param voo O voo a ser associado à reserva.
     */
    public void setVoo(Voo voo) {
        this.voo = voo;
    }
    
    /**
     * Calcula o custo da reserva de voo, considerando o custo do bilhete de voo por pessoa mais uma taxa fixa.
     * 
     * @return O custo total da reserva de voo.
     */
    @Override
    public float obterCustoReserva() {
        return voo.getCusto_bilhete() * getNumeroPessoas() + 20;
    }

    /**
     * Retorna uma representação em string da reserva de voo.
     * 
     * @return Uma representação em string da reserva de voo.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("ReservaVoo{");
        sb.append("voo=").append(voo);
        sb.append('}');
        return sb.toString();
    }
}
