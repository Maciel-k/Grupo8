/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa uma reserva de voo de ida e volta, especializando a classe ReservaVoo.
 * Calcula o custo da reserva de acordo com os voos de ida e volta escolhidos.
 * Contém métodos para acessar e definir o voo de volta associado à reserva.
 * 
 * @author pedro
 */
public class ReservaVooIdaVolta extends ReservaVoo {
    private Voo vooVolta;

    /**
     * Construtor que inicializa uma reserva de voo de ida e volta com dados específicos.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param voo           O voo de ida.
     * @param vooVolta      O voo de volta.
     */
    public ReservaVooIdaVolta(Data dataReserva, int numeroPessoas, Cliente cliente, Voo voo, Voo vooVolta) {
        super(dataReserva, numeroPessoas, cliente, voo);
        this.vooVolta = vooVolta;
    }

    /**
     * Calcula o custo da reserva de voo de ida e volta, somando os custos dos voos de ida e volta por pessoa.
     * 
     * @return O custo total da reserva de voo de ida e volta.
     */
    @Override
    public float obterCustoReserva() {
        return super.obterCustoReserva() + vooVolta.getCusto_bilhete() * getNumeroPessoas();
    }

    /**
     * Retorna uma representação em string da reserva de voo de ida e volta.
     * 
     * @return Uma representação em string da reserva de voo de ida e volta.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("ReservaVooIdaVolta{");
        sb.append("vooVolta=").append(vooVolta);
        sb.append('}');
        return sb.toString();
    }  
}

