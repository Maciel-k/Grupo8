/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

import java.util.ArrayList;
import java.util.Iterator;


/**
 * Classe principal que gerencia aeroportos, voos, clientes, hotéis e reservas.
 * Fornece métodos para adicionar e listar reservas e ordenar clientes e reservas.
 * 
 * @autor pedro
 */
public class TravelPlus {
    private ArrayList<Aeroporto> aeroportos = new ArrayList<>();
    private ArrayList<Voo> voos = new ArrayList<>();
    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Hotel> hoteis = new ArrayList<>();
    private ArrayList<Reserva> reservas = new ArrayList<>();

    /**
     * Adiciona um aeroporto à lista de aeroportos.
     * 
     * @param aeroporto O aeroporto a ser adicionado.
     */
    public void adicionarAeroporto(Aeroporto aeroporto) {
        aeroportos.add(aeroporto);
    }

    /**
     * Adiciona um voo à lista de voos.
     * 
     * @param voo O voo a ser adicionado.
     */
    public void adicionarVoo(Voo voo) {
        voos.add(voo);
    }

    /**
     * Adiciona um cliente à lista de clientes.
     * 
     * @param cliente O cliente a ser adicionado.
     */
    public void adicionarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    /**
     * Adiciona um hotel à lista de hotéis.
     * 
     * @param hotel O hotel a ser adicionado.
     */
    public void adicionarHotel(Hotel hotel) {
        hoteis.add(hotel);
    }

    /**
     * Cria uma reserva de voo.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param voo           O voo a ser reservado.
     */
    public void fazerReservaVoo(Data dataReserva, int numeroPessoas, Cliente cliente, Voo voo) {
        reservas.add(new ReservaVoo(dataReserva, numeroPessoas, cliente, voo));
    }

    /**
     * Cria uma reserva de voo de ida e volta.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param voo           O voo de ida.
     * @param vooRegresso   O voo de volta.
     */
    public void fazerReservaVooIdaVolta(Data dataReserva, int numeroPessoas, Cliente cliente, Voo voo, Voo vooRegresso) {
        reservas.add(new ReservaVooIdaVolta(dataReserva, numeroPessoas, cliente, voo, vooRegresso));
    }

    /**
     * Cria uma reserva de hotel.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param hotel         O hotel a ser reservado.
     * @param dataChegada   A data de chegada.
     * @param numeroNoites  O número de noites de estadia.
     */
    public void fazerReservaHotel(Data dataReserva, int numeroPessoas, Cliente cliente, Hotel hotel, Data dataChegada, int numeroNoites) {
        reservas.add(new ReservaHotel(dataReserva, numeroPessoas, cliente, hotel, dataChegada, numeroNoites));
    }

    /**
     * Cria uma reserva de hotel e voo.
     * 
     * @param dataReserva   A data da reserva.
     * @param numeroPessoas O número de pessoas.
     * @param cliente       O cliente que fez a reserva.
     * @param hotel         O hotel a ser reservado.
     * @param dataChegada   A data de chegada.
     * @param numeroNoites  O número de noites de estadia.
     * @param voo           O voo a ser reservado.
     */
    public void fazerReservaHotelVoo(Data dataReserva, int numeroPessoas, Cliente cliente, Hotel hotel, Data dataChegada, int numeroNoites, Voo voo) {
        reservas.add(new ReservaHotelVoo(dataReserva, numeroPessoas, cliente, hotel, dataChegada, numeroNoites, voo));
    }

    /**
     * Lista todas as reservas feitas pela empresa.
     * 
     * @return Uma string contendo as informações de todas as reservas.
     */
    public String listarReservasEmpresa() {
        StringBuilder sb = new StringBuilder();
        for (Reserva reserva : reservas) {
            sb.append(reserva.toString()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Lista todas as reservas feitas por um cliente específico.
     * 
     * @param codigoCliente O código do cliente.
     * @return Uma string contendo as informações das reservas do cliente.
     */
    public String listarReservasCliente(int codigoCliente) {
        StringBuilder sb = new StringBuilder();
        for (Reserva reserva : reservas) {
            if (reserva.getCliente().getCodigo() == codigoCliente) {
                sb.append(reserva.toString()).append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Elimina uma reserva específica com base no código da reserva.
     * 
     * @param codReserva O código da reserva a ser eliminada.
     */
    public void eliminarReserva(int codReserva) {
        Iterator<Reserva> iterator = reservas.iterator();
        while (iterator.hasNext()) {
            Reserva reserva = iterator.next();
            if (reserva.getCodigo() == codReserva) {
                iterator.remove();
            }
        }
    }

    /**
     * Ordena as reservas pela data da reserva.
     */
    public void ordenarReservas() {
        int n = reservas.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (Data.CompararDatas(reservas.get(j).getDataReserva(), reservas.get(j+1).getDataReserva())==1) {
                    // Troca reservas[j] e reservas[j+1]
                    Reserva temp = reservas.get(j);
                    reservas.set(j, reservas.get(j + 1));
                    reservas.set(j + 1, temp);
                }
            }
        }
    }

    /**
     * Ordena os clientes em ordem alfabética.
     * 
     * @return Uma string contendo os nomes dos clientes ordenados.
     */
    public String ordenarClientes() {
        ArrayList<String> clientesOrdenados = new ArrayList<>();
        for (Cliente cliente: clientes) {
            clientesOrdenados.add(cliente.getNome());
        }

        clientesOrdenados.sort(String::compareTo);
        StringBuilder sb = new StringBuilder("Clientes Ordenados: ");
        for (String cliente: clientesOrdenados) {
            sb.append(cliente + "; ");
        }
        return sb.toString();  
    }

    /**
     * Lista todos os hotéis que oferecem serviço de transfer.
     * 
     * @return Uma lista de hotéis que oferecem serviço de transfer.
     */
    public ArrayList<Hotel> listarHoteisComTransfer() {
        ArrayList<Hotel> hoteisComTransfer = new ArrayList<>();
        for (Hotel hotel : hoteis) {
            if (hotel.isTransfer()) {
                hoteisComTransfer.add(hotel);
            }
        }
        return hoteisComTransfer;
    }
}