/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proj_grupo23;

/**
 * Classe que representa um voo com informações como código, companhia aérea, lugares disponíveis,
 * aeroportos de saída e chegada, custo do bilhete e data de partida.
 * 
 * @author pedro
 */
public class Voo {
    private int codigo;
    private String nomeCompanhia;
    private int lugaresDisponiveis;
    private Aeroporto aeroportoSaida;
    private Aeroporto aeroportoChegada;
    private float custoBilhete;
    private Data dataPartida;

    // Valores padrão para inicialização
    private final String STRING_OMISSAO = "Por Definir...";
    private final int INT_OMISSAO = 0;
    private final float FLOAT_OMISSAO = 0.0f;
    private final DataHora DATA_OMISSAO = new DataHora();
    private final Aeroporto AEROPORTO_OMISSAO = new Aeroporto();

    /**
     * Construtor que inicializa um voo com informações específicas.
     * 
     * @param codigo            O código do voo.
     * @param nome_companhia    O nome da companhia aérea.
     * @param lugares_disponiveis   O número de lugares disponíveis no voo.
     * @param aeroporto_saida   O aeroporto de saída.
     * @param aeroporto_chegada O aeroporto de chegada.
     * @param custo_bilhete     O custo do bilhete do voo.
     * @param data_partida      A data de partida do voo.
     */
    public Voo(int codigo, String nome_companhia, int lugares_disponiveis, Aeroporto aeroporto_saida, Aeroporto aeroporto_chegada, float custo_bilhete, Data data_partida) {
        this.codigo = codigo;
        this.nomeCompanhia = nome_companhia;
        this.lugaresDisponiveis = lugares_disponiveis;
        this.aeroportoSaida = aeroporto_saida;
        this.aeroportoChegada = aeroporto_chegada;
        this.custoBilhete = custo_bilhete;
        this.dataPartida = data_partida;
    }
    
    /**
     * Construtor que inicializa um voo com valores padrão.
     */
    public Voo(){
        this.codigo = INT_OMISSAO;
        this.nomeCompanhia = STRING_OMISSAO;
        this.lugaresDisponiveis = INT_OMISSAO;
        this.aeroportoSaida = AEROPORTO_OMISSAO;
        this.aeroportoChegada = AEROPORTO_OMISSAO;
        this.custoBilhete = FLOAT_OMISSAO;
        this.dataPartida = DATA_OMISSAO;
    }
        
    /**
     * Construtor que inicializa um voo a partir de outro voo existente.
     * 
     * @param v1 O voo a ser copiado.
     */
    public Voo(Voo v1){
        this.codigo = v1.codigo;
        this.nomeCompanhia = v1.nomeCompanhia;
        this.lugaresDisponiveis = v1.lugaresDisponiveis;
        this.aeroportoSaida = v1.aeroportoSaida;
        this.aeroportoChegada = v1.aeroportoChegada;
        this.custoBilhete = v1.custoBilhete;
        this.dataPartida = v1.dataPartida;
    }

    // Getters e setters para os atributos do voo

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome_companhia() {
        return nomeCompanhia;
    }

    public void setNome_companhia(String nomeCompanhia) {
        this.nomeCompanhia = nomeCompanhia;
    }

    public int getLugares_disponiveis() {
        return lugaresDisponiveis;
    }

    public void setLugares_disponiveis(int lugaresDisponiveis) {
        this.lugaresDisponiveis = lugaresDisponiveis;
    }

    public Aeroporto getAeroporto_saida() {
        return aeroportoSaida;
    }

    public void setAeroporto_saida(Aeroporto aeroportoSaida) {
        this.aeroportoSaida = aeroportoSaida;
    }

    public Aeroporto getAeroporto_chegada() {
        return aeroportoChegada;
    }

    public void setAeroporto_chegada(Aeroporto aeroportoChegada) {
        this.aeroportoChegada = aeroportoChegada;
    }

    public float getCusto_bilhete() {
        return custoBilhete;
    }

    public void setCusto_bilhete(float custoBilhete) {
        this.custoBilhete = custoBilhete;
    }

    public Data getData_partida() {
        return dataPartida;
    }

    public void setData_partida(Data dataPartida) {
        this.dataPartida = dataPartida;
    }

    /**
     * Retorna uma representação em string do objeto voo, mostrando todos os seus atributos.
     * 
     * @return Uma string representando o objeto voo.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Voo{");
        sb.append("codigo=").append(codigo);
        sb.append(", nomeCompanhia=").append(nomeCompanhia);
        sb.append(", lugaresDisponiveis=").append(lugaresDisponiveis);
        sb.append(", aeroportoSaida=").append(aeroportoSaida);
        sb.append(", aeroportoChegada=").append(aeroportoChegada);
        sb.append(", custoBilhete=").append(custoBilhete);
        sb.append(", dataPartida=").append(dataPartida);
        sb.append('}');
        return sb.toString();
    }   
}
